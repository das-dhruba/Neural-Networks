## Maintainers of Deepfence SecretScanner

| Name              | Email                     | Deepfence Community Slack | GitHub                                                  | Company   |
|-------------------|---------------------------|---------------------------|---------------------------------------------------------|-----------|
| Ramanan Ravikumar | ramanan@deepfence.io      | `@Ramanan`                | [@ramanan-ravi](https://github.com/ramanan-ravi)        | Deepfence |
| Siddharth Satpathy| siddharth@deepfence.io    | `@Siddharth Satpathy `    | [@sidd0529](https://github.com/sidd0529)                | Deepfence |
| Harshvardhan Karn | harshvardhan@deepfence.io | `@harsh`                  | [@ibreakthecloud](https://github.com/ibreakthecloud)    | Deepfence |               |                      |                           |                                                   |           |

Please reach any of the maintainers on slack (#community-support on https://deepfence-community.slack.com) or email if you want to help.

## How to be maintainer?

Any contributor that shows effort, consistentcy and willingness in maintaining a repository will be invited to join the Maintainers team.

Open Source is all about the trust, which is the key factor in decision to add write permissions.

Reach us if you have any questions on how to join maintainer team.
