Please report any potential security vulnerabilities to **productsecurity *at* deepfence *dot* io**. 

Deepfence will endeavour to respond within 3 working days, and treats all security notifications in full confidence.